package Classes;

public class FlightManagement {
    public void showAllFlights() {
        System.out.println("1. Flight No 767 - From Dhaka to Delhi");
        System.out.println("2. Flight No 896 - From Dhaka to New York");
        System.out.println("3. Flight No 324 - From Dhaka to Maldives");
        System.out.println("4. Flight No 999 - From Dhaka to Chittagong");
    }
}